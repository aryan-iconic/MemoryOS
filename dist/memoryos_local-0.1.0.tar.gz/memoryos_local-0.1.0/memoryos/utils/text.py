"""Text utilities for memoryos."""
