"""Embeddings module for memoryos."""
