"""Tests for confidence scoring."""
