"""Tests for context builder."""
