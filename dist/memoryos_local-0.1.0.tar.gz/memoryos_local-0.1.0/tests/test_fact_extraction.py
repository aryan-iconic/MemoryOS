"""Tests for fact extraction."""
